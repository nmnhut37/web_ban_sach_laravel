<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Banner;
use App\Models\Product;


class CategoryController extends Controller
{
    // Hiển thị danh mục cha với danh mục con
    public function showCategories()
    {
        $parentCategories = Category::whereNull('parent_id')->with('children')->get();
        return view('layout.shop_layout', compact('parentCategories'));
    }

    // Hiển thị sản phẩm theo danh mục (cha hoặc con)
    public function showCategory($id)
    {
        $category = Category::with('children')->findOrFail($id);
        $banners = Banner::orderBy('order')->get();

        // Nếu là danh mục cha
        if (is_null($category->parent_id)) {
            // Lấy danh sách ID của danh mục cha và các danh mục con
            $categoryIds = $category->children->pluck('id')->prepend($category->id);

            // Lấy sản phẩm của danh mục cha và danh mục con
            $products = Product::whereIn('category_id', $categoryIds)->get();

            return view('shop.parent_category', compact('category', 'products', 'banners'));
        }

        // Nếu là danh mục con
        $products = $category->products()->get();
        return view('shop.child_category', compact('category', 'products', 'banners'));
    }


    // Hiển thị danh sách danh mục cha
    public function index()
    {
        $categories = Category::whereNull('parent_id')->get();
        return view('admin.product_manage.category.categories', compact('categories'));
    }

    // Hiển thị danh sách danh mục con của một danh mục cha
    public function showChildren($id)
    {
        $parentCategory = Category::findOrFail($id);
        $childCategories = $parentCategory->children()->get();
        return view('admin.product_manage.category.categories_children', compact('parentCategory', 'childCategories'));
    }

    // Tạo danh mục cha
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string|max:255',
        ]);

        Category::create([
            'name' => $request->name,
            'description' => $request->description,
            'parent_id' => null,
        ]);

        return redirect()->route('categories.index')->with('success', 'Danh mục cha đã được thêm thành công.');
    }

    // Tạo danh mục con
    public function storeChildren(Request $request, $parentCategoryId)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string|max:255',
        ]);

        Category::create([
            'name' => $request->name,
            'description' => $request->description,
            'parent_id' => $parentCategoryId,
        ]);

        return redirect()->route('categories_children', $parentCategoryId)->with('success', 'Danh mục con đã được thêm thành công.');
    }

    // Hiển thị form tạo danh mục cha
    public function create()
    {
        return view('admin.product_manage.category.categories_create');
    }

    // Hiển thị form tạo danh mục con
    public function createChildren($parentCategoryId)
    {
        $parentCategory = Category::findOrFail($parentCategoryId);
        return view('admin.product_manage.category.categories_create_children', compact('parentCategory'));
    }

    // Hiển thị form chỉnh sửa danh mục
    public function edit($id)
    {
        $category = Category::findOrFail($id);
        $categories = Category::whereNull('parent_id')->where('id', '!=', $id)->get(); // Loại trừ danh mục hiện tại
        return view('admin.product_manage.category.categories_edit', compact('category', 'categories'));
    }
    // Cập nhật danh mục
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'parent_id' => 'nullable|exists:categories,id|not_in:' . $id, // Không cho phép danh mục cha là chính nó
        ]);

        $category = Category::findOrFail($id);
        $category->update([
            'name' => $request->name,
            'description' => $request->description,
            'parent_id' => $request->parent_id,
        ]);

        return redirect()->route('categories.index')->with('success', 'Danh mục đã được cập nhật thành công.');
    }
    // Xóa danh mục
    public function destroy($id)
    {
        $category = Category::findOrFail($id);

        // Kiểm tra xem danh mục có sản phẩm hoặc danh mục con không
        if ($category->children()->exists() || $category->products()->exists()) {
            return redirect()->route('categories.index')->with('error', 'Không thể xóa danh mục có sản phẩm hoặc danh mục con.');
        }

        $category->delete();

        return redirect()->route('categories.index')->with('success', 'Danh mục đã được xóa.');
    }
}
